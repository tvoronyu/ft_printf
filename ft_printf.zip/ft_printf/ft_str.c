/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nnaumenk <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/18 19:47:59 by nnaumenk          #+#    #+#             */
/*   Updated: 2018/05/18 19:48:00 by nnaumenk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	ft_specificator(char **form, t_list *my)
{
	++(*form);
	while (my->type_field == 0 && **form)
		ft_search_s1(form, my);
	if (my->precision_field < 0)
		my->precision_field = -1;
	if (my->width_field < 0)
	{
		my->flag_minus = '-';
		my->width_field = -my->width_field;
	}
}

void	ft_strdel(char **as)
{
	if (as != NULL)
	{
		if (*as != NULL)
		{
			free(*as);
			*as = NULL;
		}
	}
}

size_t	ft_strlen(const char *s)
{
	size_t count;

	count = 0;
	while (s[count])
		count++;
	return (count);
}

char	*ft_strnew(size_t size)
{
	char *s;

	if (!(s = (char *)malloc(sizeof(char) * (size + 1))))
		return (NULL);
	s[size] = '\0';
	while (size > 0)
		s[--size] = '\0';
	return (s);
}

char	*ft_chardup(const char c)
{
	char	*str;

	str = ft_strnew(1);
	str[0] = c;
	return (str);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_color.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nnaumenk <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/12 15:11:40 by nnaumenk          #+#    #+#             */
/*   Updated: 2018/06/12 15:11:41 by nnaumenk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int		ft_str_attr_check_2(char *str_attr)
{
	if (ft_strcmp(str_attr, "white") == 0)
		return (37);
	if (ft_strcmp(str_attr, "black_b") == 0)
		return (40);
	if (ft_strcmp(str_attr, "red_b") == 0)
		return (41);
	if (ft_strcmp(str_attr, "green_b") == 0)
		return (42);
	if (ft_strcmp(str_attr, "yellow_b") == 0)
		return (43);
	if (ft_strcmp(str_attr, "blue_b") == 0)
		return (44);
	if (ft_strcmp(str_attr, "magenta_b") == 0)
		return (45);
	if (ft_strcmp(str_attr, "cyan_b") == 0)
		return (46);
	if (ft_strcmp(str_attr, "white_b") == 0)
		return (47);
	return (-1);
}

int		ft_str_attr_check(char *str_attr)
{
	if (ft_strcmp(str_attr, "eoc") == 0)
		return (0);
	if (ft_strcmp(str_attr, "bold") == 0)
		return (1);
	if (ft_strcmp(str_attr, "transparent") == 0)
		return (2);
	if (ft_strcmp(str_attr, "italic") == 0)
		return (3);
	if (ft_strcmp(str_attr, "underline") == 0)
		return (4);
	if (ft_strcmp(str_attr, "black") == 0)
		return (30);
	if (ft_strcmp(str_attr, "red") == 0)
		return (31);
	if (ft_strcmp(str_attr, "green") == 0)
		return (32);
	if (ft_strcmp(str_attr, "yellow") == 0)
		return (33);
	if (ft_strcmp(str_attr, "blue") == 0)
		return (34);
	if (ft_strcmp(str_attr, "magenta") == 0)
		return (35);
	if (ft_strcmp(str_attr, "cyan") == 0)
		return (36);
	return (ft_str_attr_check_2(str_attr));
}

void	ft_add_attribute(t_list *my, int i, int attr_len)
{
	char	*str_attr;
	int		len;
	int		start;
	int		attrib;

	str_attr = ft_strnew(attr_len);
	len = -1;
	while (++len < attr_len)
		str_attr[len] = my->str_full[i - attr_len + len];
	attrib = ft_str_attr_check(str_attr);
	ft_strdel(&str_attr);
	if (attrib == -1)
		return ;
	start = i - attr_len - 1;
	my->str_full[start] = '\x1b';
	my->str_full[start + 1] = '[';
	my->str_full[start + 2] = attrib / 10 + '0';
	my->str_full[start + 3] = attrib % 10 + '0';
	my->str_full[start + 4] = 'm';
	start += 4;
	while (i < my->len_full)
		my->str_full[++start] = my->str_full[++i];
	my->len_full = start;
}

void	ft_attribute_search(t_list *my)
{
	int		i;
	int		attr_len;

	i = -1;
	attr_len = 0;
	while (++i < my->len_full)
	{
		if (my->str_full[i] == '{')
		{
			while (++i < my->len_full)
			{
				if (my->str_full[i] == '}')
				{
					if (attr_len >= 3)
					{
						ft_add_attribute(my, i, attr_len);
						i -= attr_len;
					}
					attr_len = 0;
					break ;
				}
				++attr_len;
			}
		}
	}
}
